
using System.Collections.Generic;
using UnityEngine;


public class DataManager : MonoBehaviour
{
    public static DataManager Instance;

    public Herb[] Herbs { get; private set; }
    public Case[] Cases { get; private set; }

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
    }

    void Start()
    {
        LoadHerbs();
        LoadCases();
    }

    private void LoadHerbs()
    {
        string json = Resources.Load<TextAsset>("HerbData/Herbs").text;
        Herbs = JsonUtility.FromJson<HerbArray>(json).herbs;
    }

    private void LoadCases()
    {
        string json = Resources.Load<TextAsset>("CaseData/Cases").text;
        Cases = JsonUtility.FromJson<CaseArray>(json).cases;
    }
}