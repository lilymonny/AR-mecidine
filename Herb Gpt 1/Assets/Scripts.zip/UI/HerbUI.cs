
using UnityEngine;
using UnityEngine.EventSystems;

public class HerbUI : MonoBehaviour, IDragHandler, IEndDragHandler {
    private Transform originalParent;

    public void OnDrag(PointerEventData eventData) {
        transform.position = Input.mousePosition;
    }

    public void OnEndDrag(PointerEventData eventData) {
        // Check if dropped in the correct area
        if (eventData.pointerEnter != null && eventData.pointerEnter.CompareTag("PrescriptionArea")) {
            transform.SetParent(eventData.pointerEnter.transform);
        } else {
            transform.SetParent(originalParent);
        }
    }
}
