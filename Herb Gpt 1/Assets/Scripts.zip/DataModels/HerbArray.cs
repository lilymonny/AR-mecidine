[System.Serializable]
public class HerbArray
{
    public Herb[] herbs;
}