
using System;

[Serializable]
public class Case {
    public string id;               // Case ID
    public string description;      // Description of the case
    public string[] keySymptoms;    // Key symptoms
    public string[] recommendedHerbs; // Recommended herbs
}
