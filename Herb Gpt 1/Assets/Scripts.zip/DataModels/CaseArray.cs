
[System.Serializable]
public class CaseArray
{
    public Case[] cases;
}